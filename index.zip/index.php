<?php

$conn = mysqli_connect("localhost", "root", "", "import_excel");

if (isset($_POST['submit'])) {
		require "PHPExcel/PHPExcel/IOFactory.php";
		require "PHPExcel/PHPExcel.php";

		// echo "<pre>";
		// print_r($_FILES);
		// echo "</pre>";


	$file = $_FILES['excelFile']['tmp_name'];

	$extention = pathinfo($_FILES['excelFile']['name'], PATHINFO_EXTENSION);
	

	if ($extention=='xlsx') {
		
	
	$obj=PHPExcel_IOFactory::load($file);
	foreach ($obj->getWorksheetIterator() as $sheet) {
		// echo "<pre>";
		// print_r($sheet);
		// echo "</pre>";

		$getHighestRow=$sheet->getHighestRow();
		// echo "<pre>";
		// print_r($getHighestRow);
		// echo "</pre>";

		for ($i=2; $i <= $getHighestRow; $i++) { 


			 $fname = $sheet->getCellByColumnAndRow(0, $i)->getValue();

			 $lname = $sheet->getCellByColumnAndRow(1, $i)->getValue();

			 if ($fname !='') {
			 	$sql = "INSERT INTO `tbl_info`(`fname`, `lname`) VALUES ('$fname','$lname')";
			 	$query = mysqli_query($conn, $sql);
			 }
			 

		}
		
	}
	if($query) {
			?>
			<script>
				alert("data Inserted");
			</script>
			<?php
		}else{
			echo "error= ";
		}

  }else{
  	?>
  	<script>
  		alert("Only Excel File is allowed");
  		window.history.back();
  	</script>
  	<?php
  }
}

?>
<form method="post" enctype="multipart/form-data">
	<input type="file" name="excelFile">
	<input type="submit" name="submit" value="submit">
</form>